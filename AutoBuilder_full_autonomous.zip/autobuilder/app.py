import os
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
import stripe, sqlite3, secrets

from agents.orchestrator import heuristic_plan, llm_plan, execute_plan, optimize

load_dotenv()

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/exports", StaticFiles(directory="exports"), name="exports")
templates = Jinja2Templates(directory="templates")

scheduler = BackgroundScheduler()
scheduler.start()

# Stripe config
if os.getenv("STRIPE_SECRET"):
    stripe.api_key = os.getenv("STRIPE_SECRET")

# Credits store
CREDITS_DB = "credits.db"
RUN_COST = int(os.getenv("RUN_COST","1"))
ADMIN_KEY = os.getenv("ADMIN_KEY","admin")

def db_init():
    conn=sqlite3.connect(CREDITS_DB); c=conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS users (api_key TEXT PRIMARY KEY, credits INTEGER DEFAULT 0)")
    conn.commit(); conn.close()
db_init()

def get_credits(api_key:str)->int:
    conn=sqlite3.connect(CREDITS_DB); c=conn.cursor()
    c.execute("SELECT credits FROM users WHERE api_key=?",(api_key,))
    row=c.fetchone(); conn.close(); return row[0] if row else 0

def add_credits(api_key:str,n:int):
    conn=sqlite3.connect(CREDITS_DB); c=conn.cursor()
    c.execute("INSERT INTO users(api_key,credits) VALUES(?,COALESCE((SELECT credits FROM users WHERE api_key=?),0)+?) ON CONFLICT(api_key) DO UPDATE SET credits=credits+?", (api_key, api_key, n, n))
    conn.commit(); conn.close()

def charge(api_key:str,n:int)->bool:
    conn=sqlite3.connect(CREDITS_DB); c=conn.cursor()
    c.execute("SELECT credits FROM users WHERE api_key=?",(api_key,))
    row=c.fetchone(); cur=row[0] if row else 0
    if cur<n: conn.close(); return False
    c.execute("UPDATE users SET credits=credits-? WHERE api_key=?",(n,api_key)); conn.commit(); conn.close(); return True

def schedule_job(prompt: str):
    def job():
        plan = heuristic_plan(prompt)
        execute_plan(plan)
    scheduler.add_job(job, "interval", days=7, id=f"job-{hash(prompt)}", replace_existing=True)

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/newkey")
def new_key(admin: str = ""):
    if admin != ADMIN_KEY:
        return {"ok": False, "error": "unauthorized"}
    api_key = secrets.token_hex(16); add_credits(api_key,0)
    return {"ok": True, "api_key": api_key}

@app.get("/api/credits")
def api_credits(api_key: str = ""):
    return {"ok": True, "credits": get_credits(api_key)}

@app.post("/stripe/webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig = request.headers.get("stripe-signature","")
    secret = os.getenv("STRIPE_WEBHOOK_SECRET","")
    if not secret:
        return {"ok": False, "error": "no webhook secret"}
    try:
        event = stripe.Webhook.construct_event(payload, sig, secret)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    if event.get("type") == "checkout.session.completed":
        session = event["data"]["object"]
        api_key = (session.get("metadata") or {}).get("api_key","")
        pack = int((session.get("metadata") or {}).get("pack","10"))
        if api_key:
            add_credits(api_key, pack)
    return {"ok": True}

@app.get("/buy")
def buy(pack: int = 10, api_key: str = ""):
    secret = os.getenv("STRIPE_SECRET")
    price = os.getenv("STRIPE_PRICE_ID")
    base = os.getenv("BASE_URL","http://localhost:8080")
    if not (secret and price):
        return RedirectResponse("/", status_code=302)
    session = stripe.checkout.Session.create(
        mode="payment",
        line_items=[{"price": price, "quantity": 1}],
        metadata={"api_key": api_key, "pack": str(pack)},
        success_url=f"{base}/?ok=1",
        cancel_url=f"{base}/?canceled=1",
    )
    return RedirectResponse(session.url, status_code=303)

@app.post("/run", response_class=HTMLResponse)
async def run(request: Request):
    data = await request.json()
    api_key = (data.get("api_key") or (request.query_params.get("api_key") if hasattr(request,'query_params') else ''))
    if not api_key or not charge(api_key, RUN_COST):
        return templates.TemplateResponse("result.html", {"request": request, "summary": "Insufficient credits or missing api_key. Please purchase credits.", "logs": "No execution.", "export_path": None})
    prompt = (data.get("prompt") or "").strip()
    use_llm = bool(data.get("use_llm"))
    do_schedule = bool(data.get("schedule"))
    if not prompt:
        prompt = "Build a simple landing page that promotes a local service and exports a static site."
    # Plan + execute
    plan = llm_plan(prompt) if use_llm else heuristic_plan(prompt)
    result = execute_plan(plan)
    # Optimize + second pass
    improvements = optimize(prompt, result["logs"])
    result2 = execute_plan(plan)
    result["logs"] += f"\n\n[Optimizer Suggestions]\n{improvements}\n\n[Second Pass]\n" + result2["logs"]
    if not result.get("export_path") and result2.get("export_path"):
        result["export_path"] = result2["export_path"]
    if do_schedule:
        schedule_job(prompt)
    summary = f"Objective completed at {datetime.utcnow().isoformat()}Z. " + ("Recurring schedule enabled." if do_schedule else "")
    return templates.TemplateResponse("result.html", {"request": request, "summary": summary, **result})
