# AutoBuilder Full Autonomous

**Prompt → Plan → Execute → Optimize → Publish → Monetize**

- FastAPI + HTMX UI
- Tool registry (search, scrape, text, image, landing builder, save, email)
- Publishers: **S3**, **WordPress**, **GitHub Pages**
- **Stripe credits/paywall** (+ webhook): sell runs; `/run` charges credits
- **Scheduler** (APScheduler) for passive recurring runs
- **Continuous optimization loop** (auto second pass)
- n8n webhook notify support
- Render / Railway deploy manifests

## Quickstart (Local)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # fill keys
uvicorn app:app --host 0.0.0.0 --port 8080 --reload
```
Visit http://localhost:8080

## Monetization (Stripe + Credits)
1) Create a Stripe Price for credits; set `STRIPE_PRICE_ID` and `STRIPE_SECRET`.
2) Configure webhook to `POST /stripe/webhook`, put its `STRIPE_WEBHOOK_SECRET` in env.
3) Create an API key: `GET /api/newkey?admin=YOUR_ADMIN_KEY`.
4) Check credits: `/api/credits?api_key=THE_KEY`.
5) Buy: `/buy?api_key=THE_KEY&pack=10` (webhook will add credits).
6) `/run` requires credits; each run costs `RUN_COST`.

## Email Notifications
Set `SMTP_*` in env; include in your prompt: “email the summary to me@example.com”.

## Render / Railway
Use `render.yaml` or `railway.json`. Add env vars from `.env.example` + Stripe vars.

## n8n
Set `N8N_WEBHOOK_URL` to notify a webhook after each run.
