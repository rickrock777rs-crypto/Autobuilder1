import os, json, uuid
from typing import List, Dict, Any
from pydantic import BaseModel
from .tools import REGISTRY, list_tools, ToolResult

class Step(BaseModel):
    tool: str
    args: Dict[str, Any]

class Plan(BaseModel):
    objective: str
    steps: List[Step]

def heuristic_plan(prompt: str) -> Plan:
    steps = []
    p = prompt.lower()
    if "landing page" in p or "website" in p or "page" in p:
        steps.append(Step(tool="generate_text", args={"prompt": f"Write compelling landing page copy for: {prompt}. Include a punchy headline and 2 paragraphs."}))
        steps.append(Step(tool="create_image", args={"prompt": f"Hero image for: {prompt}"}))
        steps.append(Step(tool="build_landing_page", args={"title":"AutoBuilder Site", "copy":"[[COPY]]", "image_url":"[[IMAGE]]"}))
        steps.append(Step(tool="save_file", args={"path": f"exports/{uuid.uuid4().hex}/index.html", "content":"[[HTML]]"}))
        # Optional publishing if configured
        steps.append(Step(tool="publish_s3", args={"path": "[[EXPORT]]"}))
    else:
        steps.append(Step(tool="web_search", args={"query": prompt}))
        steps.append(Step(tool="generate_text", args={"prompt": f"Summarize findings and propose next actions for: {prompt}"}))
        steps.append(Step(tool="save_file", args={"path": f"exports/{uuid.uuid4().hex}/summary.txt", "content":"[[TEXT]]"}))
    return Plan(objective=prompt, steps=steps)

def llm_plan(prompt: str) -> Plan:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return heuristic_plan(prompt)
    from openai import OpenAI
    client = OpenAI(api_key=key)
    schema = {
        "type":"object",
        "properties":{"steps":{"type":"array","items":{"type":"object","properties":{"tool":{"type":"string","enum":list(REGISTRY.keys())},"args":{"type":"object"}}, "required":["tool","args"]}}},
        "required":["steps"]
    }
    sys = f"You are a planner that creates a minimal, effective sequence of tools to accomplish: {prompt}. Use only these tools: {list(list_tools().keys())}. Prefer short plans (2-5 steps). Persist results with save_file or build_landing_page then optionally publish via S3/WP/GitHub Pages and notify via email/n8n."
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"system","content":sys},{"role":"user","content":prompt}],
        temperature=0.2,
        functions=[{"name":"make_plan","parameters":schema}],
        function_call={"name":"make_plan"}
    )
    args = json.loads(resp.choices[0].message.function_call.arguments)
    steps = [Step(**s) for s in args.get("steps", [])]
    if not steps:
        return heuristic_plan(prompt)
    return Plan(objective=prompt, steps=steps)

def execute_plan(plan: Plan) -> Dict[str, Any]:
    logs = []
    export_path = None
    memory = {"COPY":"", "IMAGE":"", "HTML":"", "TEXT":"", "EXPORT":""}

    def log(msg): logs.append(msg)

    for i, step in enumerate(plan.steps, start=1):
        tool = REGISTRY.get(step.tool)
        if not tool:
            log(f"[{i}] Unknown tool: {step.tool}"); continue
        resolved_args = {}
        for k,v in step.args.items():
            if isinstance(v, str) and v.startswith("[[") and v.endswith("]]"):
                key = v.strip("[]")
                resolved_args[k] = memory.get(key, "")
            else:
                resolved_args[k] = v
        log(f"[{i}] {tool.name} -> {resolved_args}")
        res = tool.run(**resolved_args)
        log(f"    result: {str(res)[:240]}")
        if tool.name == "generate_text":
            memory["TEXT"] = res.get("data",""); memory["COPY"] = res.get("data","")
        if tool.name == "create_image":
            memory["IMAGE"] = res.get("data","")
        if tool.name == "build_landing_page":
            memory["HTML"] = res.get("data","")
        if tool.name == "save_file":
            export_path = res.get("data"); memory["EXPORT"] = export_path

    return {"logs":"\n".join(logs), "export_path": f"/{export_path}" if export_path else None}

def optimize(prompt: str, logs: str) -> str:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return "Consider: clarify niche, add CTA, optimize images, schedule weekly refresh, enable Stripe credits."
    from openai import OpenAI
    client = OpenAI(api_key=key)
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"system","content":"You are a product optimizer. Return concise improvements."},
                  {"role":"user","content":f"Objective: {prompt}\nLogs:\n{logs}\nSuggest improvements to speed, capability, and design."}],
        temperature=0.4
    )
    return resp.choices[0].message.content
