import os, time, json, re, requests
from bs4 import BeautifulSoup

class ToolResult(dict):
    pass

class BaseTool:
    name: str = "base"
    description: str = "Base tool"
    def run(self, **kwargs) -> ToolResult:
        raise NotImplementedError

class WebSearch(BaseTool):
    name = "web_search"
    description = "Search the web (SerpAPI if available)."
    def run(self, query: str) -> ToolResult:
        key = os.getenv("SERPAPI_API_KEY")
        if key:
            url = "https://serpapi.com/search.json"
            resp = requests.get(url, params={"engine":"google", "q":query, "api_key":key}, timeout=30)
            data = resp.json()
            results = [item["title"] + " - " + item.get("link","") for item in data.get("organic_results", [])[:5]]
            return ToolResult(ok=True, tool=self.name, data=results)
        return ToolResult(ok=True, tool=self.name, data=[f"(No SERPAPI key) Consider searching: {query}"])

class WebScrape(BaseTool):
    name = "web_scrape"
    description = "Fetch URL and extract main text."
    def run(self, url: str) -> ToolResult:
        r = requests.get(url, timeout=30, headers={"User-Agent":"Mozilla/5.0"})
        soup = BeautifulSoup(r.text, "html.parser")
        texts = [t.get_text(" ", strip=True) for t in soup.find_all(["p","h1","h2","h3","li"])]
        return ToolResult(ok=True, tool=self.name, data="\n".join(texts)[:5000])

class GenerateText(BaseTool):
    name = "generate_text"
    description = "Use OpenAI to generate text."
    def run(self, prompt: str, system: str = "You are a helpful assistant.") -> ToolResult:
        from openai import OpenAI
        key = os.getenv("OPENAI_API_KEY")
        if not key:
            return ToolResult(ok=True, tool=self.name, data=f"(No OPENAI_API_KEY) Draft: {prompt[:400]}")
        client = OpenAI(api_key=key)
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role":"system","content":system},{"role":"user","content":prompt}],
            temperature=0.7
        )
        return ToolResult(ok=True, tool=self.name, data=resp.choices[0].message.content)

class CreateImage(BaseTool):
    name = "create_image"
    description = "Create an image via OpenAI Images API."
    def run(self, prompt: str) -> ToolResult:
        key = os.getenv("OPENAI_API_KEY")
        if not key:
            return ToolResult(ok=True, tool=self.name, data="(No OPENAI_API_KEY) Skipped image generation.")
        from openai import OpenAI
        client = OpenAI(api_key=key)
        img = client.images.generate(model="gpt-image-1", prompt=prompt, size="1024x1024", n=1)
        url = img.data[0].url
        return ToolResult(ok=True, tool=self.name, data=url)

class SaveFile(BaseTool):
    name = "save_file"
    description = "Save content to local file inside exports/."
    def run(self, path: str, content: str) -> ToolResult:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return ToolResult(ok=True, tool=self.name, data=path)

class BuildLandingPage(BaseTool):
    name = "build_landing_page"
    description = "Generate a static landing page from title, copy, and optional image URL."
    def run(self, title: str, copy: str, image_url: str = "") -> ToolResult:
        html = f"""<!DOCTYPE html>
<html lang='en'><head>
<meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'>
<title>{title}</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
<style>body{{font-family:Inter,system-ui,sans-serif;margin:0;background:#0b1220;color:#fff}}.hero{{padding:64px 24px;text-align:center;background:linear-gradient(180deg,#0b1220,#14213d)}}h1{{font-size:48px;margin:0}}p{{max-width:820px;margin:16px auto;font-size:18px;line-height:1.6;color:#d9e3f0}}.cta{{margin-top:24px}}a.btn{{background:#10b981;color:#001b2e;padding:12px 18px;border-radius:12px;text-decoration:none;font-weight:700}}.wrap{{max-width:960px;margin:0 auto;padding:24px}}img.heroimg{{max-width:680px;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.4);margin-top:16px}}</style>
</head><body>
<section class="hero">
  <h1>{title}</h1>
  <p>{copy}</p>
  {'<img class="heroimg" src="'+image_url+'" />' if image_url else ''}
  <div class="cta"><a class="btn" href="#lead">Get Started</a></div>
</section>
<section id="lead" class="wrap">
  <h2>Join the waitlist</h2>
  <form action="https://formspree.io/f/xyz" method="POST">
    <input name="email" type="email" placeholder="you@example.com" required style="padding:12px;border-radius:12px;border:none;min-width:240px">
    <button type="submit" style="padding:12px 18px;border-radius:12px;background:#f59e0b;color:#001b2e;font-weight:800">Notify Me</button>
  </form>
  <p style="color:#9fb3c8">Replace the form action with your form provider or n8n webhook.</p>
</section>
</body></html>"""
        return ToolResult(ok=True, tool=self.name, data=html)

class PublishS3(BaseTool):
    name = "publish_s3"
    description = "Upload a file to S3 and return the public URL."
    def run(self, path: str, key: str = None) -> ToolResult:
        import boto3, mimetypes
        bucket = os.getenv("AWS_S3_BUCKET")
        region = os.getenv("AWS_S3_REGION","us-east-1")
        if not bucket:
            return ToolResult(ok=False, tool=self.name, data="S3 not configured")
        s3 = boto3.client("s3", region_name=region)
        if not key:
            key = os.path.basename(path)
        ctype, _ = mimetypes.guess_type(path)
        with open(path, "rb") as f:
            s3.put_object(Bucket=bucket, Key=key, Body=f, ACL="public-read", ContentType=(ctype or "application/octet-stream"))
        url = f"https://{bucket}.s3.{region}.amazonaws.com/{key}"
        return ToolResult(ok=True, tool=self.name, data=url)

class PublishWordPress(BaseTool):
    name = "publish_wordpress"
    description = "Publish HTML as a WordPress post via REST API."
    def run(self, title: str, html: str, status: str = "publish") -> ToolResult:
        base = os.getenv("WP_BASE_URL","").rstrip("/")
        user = os.getenv("WP_USERNAME","")
        apppw = os.getenv("WP_APP_PASSWORD","")
        if not (base and user and apppw):
            return ToolResult(ok=False, tool=self.name, data="WordPress not configured")
        url = f"{base}/wp-json/wp/v2/posts"
        r = requests.post(url, auth=(user, apppw), json={"title": title, "content": html, "status": status}, timeout=30)
        try:
            j = r.json()
        except Exception:
            return ToolResult(ok=False, tool=self.name, data=f"HTTP {r.status_code}: {r.text[:300]}")
        if r.status_code in (200,201):
            return ToolResult(ok=True, tool=self.name, data=j.get("link"))
        return ToolResult(ok=False, tool=self.name, data=str(j))

class PublishGitHubPages(BaseTool):
    name = "publish_github_pages"
    description = "Commit a file to a GitHub repo/branch and return a raw URL."
    def run(self, path: str, repo: str = None, branch: str = None, dest_path: str = None) -> ToolResult:
        token = os.getenv("GITHUB_TOKEN")
        repo = repo or os.getenv("GITHUB_REPO")
        branch = branch or os.getenv("GITHUB_BRANCH","gh-pages")
        if not (token and repo):
            return ToolResult(ok=False, tool=self.name, data="GitHub not configured")
        with open(path, "rb") as f:
            content_b64 = __import__("base64").b64encode(f.read()).decode()
        api = f"https://api.github.com/repos/{repo}/contents/{dest_path or os.path.basename(path)}"
        headers = {"Authorization": f"token {token}", "Accept":"application/vnd.github+json"}
        # Try read to get SHA
        sha = None
        rget = requests.get(api, headers=headers, params={"ref": branch}, timeout=30)
        if rget.status_code == 200:
            sha = rget.json().get("sha")
        payload = {"message": "AutoBuilder publish", "content": content_b64, "branch": branch}
        if sha: payload["sha"] = sha
        rput = requests.put(api, headers=headers, json=payload, timeout=30)
        if rput.status_code in (200,201):
            raw = f"https://raw.githubusercontent.com/{repo}/{branch}/{dest_path or os.path.basename(path)}"
            return ToolResult(ok=True, tool=self.name, data=raw)
        return ToolResult(ok=False, tool=self.name, data=f"{rput.status_code}: {rput.text[:300]}")

class NotifyN8N(BaseTool):
    name = "notify_n8n"
    description = "Send a JSON payload to an n8n webhook URL."
    def run(self, payload: dict) -> ToolResult:
        url = os.getenv("N8N_WEBHOOK_URL")
        if not url:
            return ToolResult(ok=False, tool=self.name, data="N8N_WEBHOOK_URL not set")
        r = requests.post(url, json=payload, timeout=30)
        return ToolResult(ok=True, tool=self.name, data=f"n8n status {r.status_code}")

class SendEmail(BaseTool):
    name = "send_email"
    description = "Send a basic email via SMTP."
    def run(self, to: str, subject: str, body: str) -> ToolResult:
        import smtplib
        from email.mime.text import MIMEText
        host = os.getenv("SMTP_HOST"); port=int(os.getenv("SMTP_PORT","587"))
        user = os.getenv("SMTP_USER"); pw = os.getenv("SMTP_PASS"); from_addr=os.getenv("SMTP_FROM") or user
        if not (host and user and pw and from_addr):
            return ToolResult(ok=False, tool=self.name, data="SMTP not configured")
        msg = MIMEText(body, "html")
        msg["Subject"]=subject; msg["From"]=from_addr; msg["To"]=to
        with smtplib.SMTP(host, port) as s:
            s.starttls(); s.login(user, pw); s.sendmail(from_addr, [to], msg.as_string())
        return ToolResult(ok=True, tool=self.name, data="sent")

REGISTRY = {
    "web_search": WebSearch(),
    "web_scrape": WebScrape(),
    "generate_text": GenerateText(),
    "create_image": CreateImage(),
    "save_file": SaveFile(),
    "build_landing_page": BuildLandingPage(),
    "publish_s3": PublishS3(),
    "publish_wordpress": PublishWordPress(),
    "publish_github_pages": PublishGitHubPages(),
    "notify_n8n": NotifyN8N(),
    "send_email": SendEmail(),
}

def list_tools():
    return {k: v.description for k, v in REGISTRY.items()}
