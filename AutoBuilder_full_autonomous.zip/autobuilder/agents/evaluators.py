def simple_score(text: str) -> int:
    return min(100, max(10, len(text)//20))
